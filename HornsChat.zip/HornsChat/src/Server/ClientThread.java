package Server;

import java.io.*;
import java.net.*;
import javafx.application.*;
import javafx.collections.*;
import javafx.event.*;
import javafx.geometry.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;
import javafx.scene.text.Text;
import javafx.stage.Stage;


public class ClientThread extends Application{
    private String name;
    private String hostIP;
    private int port;
    private BufferedReader reader;
    private PrintWriter writer;
    private GridPane grid;


    public void start(Stage primaryStage){
        try{
            grid = new GridPane();
            grid.setHgap(5);
            grid.setVgap(5);
            grid.setPrefWidth(360);
            grid.setPadding(new Insets(10, 10, 10, 10));

            //Add Username
            int row = 0;
            Label username = new Label("Username:");
            grid.add(username, 0, row);

            TextField nameField = new TextField();
            grid.add(nameField, 1, row);

            //Add host options
            row += 2;
            Label host = new Label("Host:");
            grid.add(host, 0, row);

            TextField hostAddress = new TextField();
            grid.add(hostAddress, 1, row);

            row += 2;
            Label port = new Label("Port:");
            grid.add(port, 0, row);

            TextField portNumber = new TextField();
            grid.add(portNumber, 1, row);

            //Add login button
            row += 2;
            Button login = new Button("Login");
            login.setPrefWidth(70);
            HBox loginBox = new HBox(10);
            loginBox.setAlignment(Pos.BOTTOM_LEFT);
            loginBox.getChildren().add(login);
            grid.add(loginBox, 1, row);

            Button quit = new Button("Quit");
            quit.setPrefWidth(70);
            HBox quitBox = new HBox(10);
            quitBox.setAlignment(Pos.BOTTOM_LEFT);
            quitBox.getChildren().add(quit);
            grid.add(quitBox, 2, row);


            Stage stage = new Stage();
            stage.setTitle("Horn Chat Login");
            stage.setScene(new Scene(grid, 360, 180));
            stage.setAlwaysOnTop(true);
            stage.show();

            login.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event){
                    String username = nameField.getText();
                    String hostIP = hostAddress.getText();
                    int port = Integer.parseInt(portNumber.getText());
                    setLogin(username, hostIP, port);
                    connect();
                    sendUsername();
                    stage.close();
                }
            });

            quit.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event){
                    System.exit(0);
                }
            });

            primaryStage.setTitle("Project 7 Horns Chat");
            grid = new GridPane();
            Scene scene = new Scene(grid, 720, 640);
            primaryStage.setScene(scene);
            primaryStage.show();

            //new ClientThread().run();
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }

    public void setLogin(String name, String hostIP, int port){
        this.port = port;
        this.hostIP = hostIP;
        this.name = name;
    }

    private void connect(){
        try{
            @SuppressWarnings("resource")
            Socket sock = new Socket(hostIP, port);
            InputStreamReader streamReader = new InputStreamReader(sock.getInputStream());
            reader = new BufferedReader(streamReader);
            writer = new PrintWriter(sock.getOutputStream());
            System.out.println("networking established");
            Thread readerThread = new Thread(new IncomingReader());
            readerThread.start();
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }

    private void sendUsername(){
        writer.println("/set " + name);
        writer.flush();
    }

    public String getClientName(){
        return this.name;
    }


    public static void main(String[] args) {
        launch(args);
    }

    class IncomingReader implements Runnable {
        public void run() {
            String message;
            try {
                while ((message = reader.readLine()) != null) {

                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }
}
