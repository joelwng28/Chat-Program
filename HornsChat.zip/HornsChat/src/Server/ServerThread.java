package Server;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;

public class ServerThread{
    private boolean isOpen;
    private int count = 0;
    private ServerSocket serverSocket;
    private int port = 9001;
    protected ArrayList<PrintWriter> oos;
    protected ArrayList<String> userNameList;
    protected HashMap<String, ClientThread> userMap;




    public ServerThread() {
        this.isOpen = true;
        this.userMap = new HashMap<>();
        this.userNameList = new ArrayList<>();
        this.oos = new ArrayList<>();
    }

    public ServerSocket getServerSocket() {
        return serverSocket;
    }

    public void setOpen(boolean isOpen){
        this.isOpen = isOpen;
    }

    private void setUpNetworking() throws Exception {
        @SuppressWarnings("resource")
        ServerSocket serverSock = new ServerSocket(port);
        System.out.println("Server established");
        while (isOpen) {
            //Accepting clients
            Socket clientSocket = serverSock.accept();

            PrintWriter writer = new PrintWriter(clientSocket.getOutputStream());
            oos.add(writer);

            //Creating clients
            /*
            ClientThread client = new ClientThread(clientSocket);
            userNameList.add(client.getClientName());
            userMap.put(client.getClientName(), client);
            */

            //Starting new client thread
            Thread t = new Thread(new ClientHandler(clientSocket));
            t.start();

            count ++;
            System.out.println("Got a new connection");
            System.out.println("Client #" + count);
        }

    }

    private void notifyClients(String message) {
        for (PrintWriter writer : oos) {
            writer.println(message);
            writer.flush();
        }
    }

    class ClientHandler implements Runnable {
        private BufferedReader reader;

        public ClientHandler(Socket clientSocket) throws IOException {
            Socket sock = clientSocket;
            reader = new BufferedReader(new InputStreamReader(sock.getInputStream()));
        }

        public void run() {
            System.out.println("ClientHandler has started");

            String message;
            try {
                while ((message = reader.readLine()) != null) {
                    String[] parse = message.split(" ");

                    if(parse[0].equals("/set")) {
                        userNameList.add(parse[1]);
                        System.out.println(userNameList);
                    }

                    if(parse[0].equals("/private")) {
                        String name = parse[1];
                    }

                    if(parse[0].equals("/quit")) {
                        String name = parse[1];
                    }

                    System.out.println("read " + message);
                    notifyClients(message);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) throws Exception{
        ServerThread serverThread = new ServerThread();
        serverThread.setUpNetworking();
    }
}